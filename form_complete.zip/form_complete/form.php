<?php
if(isset($_POST['submit'])){  //check if the button was submitted
  //getting info from index.php
  $name=$_POST['name'];
  $surname=$_POST['surname'];
  $gendre=$_POST['gendre'];
  $d_o_b=$_POST['d_o_b'];
  $maritual_status=$_POST['maritual_status'];
  $type_of_accomo=$_POST['type_of_accomo'];
  $city=$_POST['city'];
  $province=$_POST['province'];
  $district=$_POST['district'];
  $address=$_POST['address'];
  $mobile=$_POST['mobile'];
  $landline=$_POST['landline'];
  $e_mail=$_POST['e-mail'];
  $other_networkings=$_POST['other_networkings'];

  $occupation=$_POST['occupation'];
  $place_of_work=$_POST['place_of_work'];
  $date_you_enter_to_the_country=$_POST['date_you_enter_to_the_country'];
  $residence_permit_no=$_POST['residence_permit_no'];
  $type_of_reside=$_POST['type_of_reside'];
  $expire_date_of_your_residence_permit=$_POST['expire_date_of_your_residence_permit'];
  $level_of_educ=$_POST['level_of_educ'];
  $level_of_engl=$_POST['level_of_engl'];

  $blood_group=$_POST['blood_group'];
  $rh=$_POST['rh'];
  $medical_insurance=$_POST['medical_insurance'];
  $chron_diseases=$_POST['chron_diseases'];
  $medical_notes=$_POST['medical_notes'];

  $mentorship_training_educating_donation_volunteering=$_POST['mentorship_training_educating_donation_volunteering'];
  $advices_problems=$_POST['advices_problems'];

  $wife_husband_name=$_POST['wife_husband_name'];
  $wife_husband_surname=$_POST['wife_husband_surname'];
  $wife_husband_details=$_POST['wife_husband_details'];

  $first_child_name=$_POST['first_child_name'];
  $first_child_surname=$_POST['first_child_surname'];
  $first_child_details=$_POST['first_child_details'];

  $second_child_name=$_POST['second_child_name'];
  $second_child_surname=$_POST['second_child_surname'];
  $second_child_details=$_POST['second_child_details'];

  //upload image to directory

if($_FILES['photo']['name']){
  $file_exists=true;
  $direct='images'; //directory where the foto schould be saved
  $photo_name = strtolower($_FILES['photo']['name']);  //change file name to lower case
  $photo_src=$direct.'/'.$photo_name;  //the direction to photo

  if(!$_FILES['photo']['error']){
      while($file_exists==true){  //check if there are any photos with the same name
          if(file_exists($photo_src)){
            $photo_type=substr($photo_src,strlen($photo_src)-4);
            $photo_src=substr($photo_src,0,strlen($photo_src)-4).'n'.$photo_type;
          }else{
          move_uploaded_file($_FILES['photo']['tmp_name'],$photo_src);
          $file_exists=false;
          }
      }
    }else{
      $message = 'Ooops!  Your upload triggered the following error:  '.$_FILES['photo']['error'];
    }
  }

  //conect and send information to database
  $host='localhost';  //host name where situated database
  $user_name='id1264943_form_user'; //user_name
  $password='form-123-form';  //password
  $db_name='id1264943_form_saver';  //name of databse
  $table_name='form1'; //name of table
    	$db=mysqli_connect($host,$user_name,$password,$db_name);
    	if(mysqli_connect_errno()){
    		echo("Some troubles, during the connection to database (".mysqli_connect_errno()."): ".mysqli_connect_error());
    		exit();
    	}

    $db_query=mysqli_query($db,"INSERT INTO ".$table_name."(name,surname,gendre,d_o_b,maritual_status,type_of_accomo,city,province,district,address,mobile,landline,e-mail,other_networkings,occupation,place_of_work,date_you_enter_to_the_country,residence_permit_no,type_of_reside,expire_date_of_your_residence_permit,level_of_educ,level_of_engl,blood_group,rh,medical_insurance,chron_diseases,medical_notes,mentorship_training_educating_donation_volunteering,advices_problems,photo_name,photo_src,wife_husband_name,wife_husband_surname,wife_husband_details,first_child_name,first_child_surname,first_child_details,second_child_name,second_child_surname,second_child_details) VALUE('$name','$surname','$gendre','$d_o_b','$maritual_status','$type_of_accomo','$city','$province','$district','$address','$mobile','$landline','$e_mail','$other_networkings','$occupation','$place_of_work','$date_you_enter_to_the_country','$residence_permit_no','$type_of_reside','$expire_date_of_your_residence_permit','$level_of_educ','$level_of_engl','$blood_group','$rh','$medical_insurance','$chron_diseases','$medical_notes','$mentorship_training_educating_donation_volunteering','$advices_problems','$photo_name','$photo_src','$wife_husband_name','$wife_husband_surname','$wife_husband_details','$first_child_name','$first_child_surname','$first_child_details','$second_child_name','$second_child_surname','$second_child_details')");
    echo " <!DOCTYPE html>
     <html>
       <head>
       <link rel='stylesheet' href='//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css'>
       <link rel='stylesheet' href='style.css'>
       <meta charset='utf-8'>
       <script src='js/jquery.js'></script>
       <script src='js/jquery_ui.js'></script>
       <script src='js/script.js'></script>
       <title></title>
       </head>
       <body>
         <div id='container' class='form_text'>
           Thank you for your time and all the information you give , ".$name."!
        </div>
       </body>
     </html>
  "; //echo save words about completing


}













 ?>
