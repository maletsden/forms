  $(function(){
    //positio for input with type file
    $('.file').offset({left:$('.file_photo').offset().left });

    input_file();
    // RESIZE
    $(window).resize(function(){
      input_file();
    });
  });


  // open file before upload
function readURL(input) {
      if (input.files && input.files[0]) {
          var reader = new FileReader();
          reader.onload = function (e) {
              $('#blah').attr('src', e.target.result);
          };

          reader.readAsDataURL(input.files[0]);
      }
  }
//stylish elements
function input_file(){
  if ($(window).width()<750){
    $('.file_photo').parent().removeClass('center').addClass('left');
    $('input[type="file"]').parent().removeClass('center').addClass('left');
  }
  else{
    $('.file_photo').parent().removeClass('left').addClass('center');
    $('input[type="file"]').parent().removeClass('left').addClass('center');
  }
  $('.file_photo').ready(function(){
    $('.file_photo').width($('.file_photo').parent().width());
  });
}
