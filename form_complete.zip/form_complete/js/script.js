var i,q,error,a,seccess;
$( function() {
  form_focus();
  privious_page();
  $("#second_page,#third_page,#fourth_page").hide();
  protect();
  $('select').change(function () {
    $(this).css('border','');
  });
});


//check if all the inputs are filled and allow to save info to database(used only in the last page)
function save(){
  $('form').submit(function() {
  var error=false;
    for(var i=25;i<27;i++){
      if($('input[alt="'+i+'"]').attr('title')==$('input[alt="'+i+'"]').val()){
      $('input[alt="'+i+'"]').css('border','1px solid red');
      error=true;
      console.log(i,error);
      }
    }
    if(error==false){
      console.log('seccess',error);
        $('input[alt="'+i+'"]').attr('status',i);
        if($('input[alt="'+i+'"]').attr('status')==$('input[alt="27"]').attr('status')){
          $("#fourth_page").hide("slow");
        }
    }else{
      return false;
    }
  });
}

//check if all the inputs are filled
function check(i,a) {
  var error=false;
    for(i;i<a;i++){
        if(i==4 || i==17 || i==19 || i==20 || i==21 || i==22){
          if($('select[alt="'+i+'"]').attr('title')==$('select[alt="'+i+'"]').val()){
            $('select[alt="'+i+'"]').css('border','1px solid red');
            error=true;
            console.log('select');
          }
        }else{
          if($('input[alt="'+i+'"]').attr('title')==$('input[alt="'+i+'"]').val()){
          $('input[alt="'+i+'"]').css('border','1px solid red');
          error=true;
          console.log(i,error);
          }
        }
      }
      if($('.file_photo').attr('src')=='images/avatar_img.png'){
          error=true;
          console.log('img');
      }
    if(error==false){
      console.log('seccess',error);
        $('i[alt="'+i+'"]').attr('status',i);
      if($('i[alt="'+i+'"]').attr('status')==$('i[alt="13"]').attr('status')){
        $("#second_page").show("slow");
        $("#first_page").hide("slow");
      }
      if($('i[alt="'+i+'"]').attr('status')==$('i[alt="21"]').attr('status')){
        $("#second_page").hide("slow");
        $("#third_page").show("slow");
      }
      if($('i[alt="'+i+'"]').attr('status')==$('i[alt="25"]').attr('status')){
        $("#fourth_page").show("slow");
        $("#third_page").hide("slow");
      }
    }else{
      return false;
    }
}

//redirecting to privious pages
function privious_page() {
  $("#back1").click(function(){
    $("#second_page").hide("slow");
    $("#first_page").show("slow");
  });
  $("#back2").click(function(){
    $("#third_page").hide("slow");
    $("#second_page").show("slow");
  });
  $("#back3").click(function(){
    $("#fourth_page").hide("slow");
    $("#third_page").show("slow");
  });
}
//free up the inputs on focus
function form_focus(){
  $( "#datepicker,#datepicker1,#datepicker2" ).datepicker({
      changeMonth: true,
      changeYear: true,
      yearRange: "1960:2017"
    });
  $('.datepicker').click(function(){
    $( "#datepicker1[alt='9']" ).focus();
  });
  $('input').focus(function(){
    if($(this).attr('title')==$(this).val()){
      $(this).css({'border':'','color':'#000'}).val('');
    }
  });
  $('input').blur(function(){
    if($(this).val()==''){
      $(this).val($(this).attr('title')).css({'color':'#99999f'});
    }
  });
}
//protect your database
function protect(){
  $('input').keyup(function () {
    if ($(this).val().search('<') != -1){
      $(this).val($(this).val().replace('<',''));
    }
    if ($(this).val().search('>') != -1){
      $(this).val($(this).val().replace('>',''));
    }
    if ($(this).val().search('SELECT') != -1){
      $(this).val($(this).val().replace('SELECT',''));
    }
  });
}
