<html>
  <head>
    <title></title>
    <meta charset="utf-8">
    <!-- JQuery -->
    <script src="js/jquery.js"></script>
    <!-- JQuery UI -->
    <script src="js/jquery_ui.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <!-- scripts -->
    <script src="js/script.js"></script>
    <script src="js/input_file.js"></script>
    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <!-- Font-Awesome -->
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.css">
    <!-- main_css -->
    <link rel="stylesheet" href="css/style.css">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <script type="text/javascript">
  </script>
<body>
<div class="container">
  <div class='general_info'>General Information Form</div>
  <div class="text_cen">This form ask your very basic information for us to know your background better.Therefore, we and you could have a chance to help as well as receive aid from the community. Please fill every field faithfully.</div>
    <form method="POST" action="form.php" enctype="multipart/form-data">

      <!-- 1-st page -->
      <div id='first_page'>
        <div class="row">
          <!-- first column -->
          <div class='col-xs-10 col-sm-10 col-md-6 col-lg-6  col-xs-offset-1 col-sm-offset-1 col-md-offset-1 col-lg-offset-1'>
              <div class='tr'>
                <input type='text' alt="1" class="input" name='name' title='Your name' value='Your name'>
              </div>
              <div class='tr'>
                <input type='text' alt="2" class='input'  name='surname' title='Your surname' value='Your surname'>
              </div>
              <div class='tr'>
                <label class="radio-inline">
                  <input type="radio" checked name="gendre" value="Male">Male
                </label>
                <label class="radio-inline">
                  <input type="radio" name='gendre' value="Female">Female
                </label>
              </div>
              <div class='tr'>
                <input type='text' alt="3" class='input' id='datepicker' name='d_o_b' title='Date of Birth' value='Date of Birth'>
              </div>
              <div class='tr flex_space_betw'>
                  <select name='maritual_status' alt="4"  class="input flex_item_100" title='Maritual Status'>
                    <option>Maritual Status</option>
                    <option value='Single'>Single</option>
                    <option value="Married">Married</option>
                    <option value="Divorced">Divorced</option>
                  </select>
              </div>
          </div>
          <!-- second column -->
          <div class='col-xs-10 col-sm-10 col-md-5 col-lg-5  col-xs-offset-1 col-sm-offset-1 col-md-offset-0 col-lg-offset-0'>
            <div class="row">
              <div class='col-xs-6 col-sm-6 col-md-12 col-lg-12'>
                <div class='col-xs-10 col-sm-10 col-md-7 col-lg-7 center' style='margin-bottom:20px;'>
                  <img id="blah" class='file_photo' src="images/avatar_img.png" alt="your image" />
                </div>
              </div>
              <div class='col-xs-6 col-sm-6 col-md-12 col-lg-12'>
                <div class='col-xs-10 col-sm-10 col-md-7 col-lg-7 center'>
                  <label class="btn btn-default btn-file" >
                    Browse...<input type="file" onchange="readURL(this);" name="photo" multiple>
                  </label>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- hr -->
        <div class="row">
          <div class=" col-xs-10 col-sm-10 col-md-10 col-lg-10  col-xs-offset-1 col-sm-offset-1 col-md-offset-1 col-lg-offset-1">
            <hr class='hr'>
          </div>
        </div>
        <!-- end hr -->
        <div class="row">
          <div class='row col-xs-10 col-sm-10 col-md-10 col-lg-10 col-xs-offset-1 col-sm-offset-1 col-md-offset-1 col-lg-offset-1'>
            <div class='tr' >
              Type of the Accommodation :
              <label class="radio-inline">
                <input type="radio" checked name="type_of_accomo" value="Owned">Owned
              </label>
              <label class="radio-inline">
                <input type="radio" name="type_of_accomo" value="Rented">Rented
              </label>
            </div>
            <div class='tr'>
              <input type='text'  alt="5" title='City' class='input1' name='city' value="City">
            </div>
            <div class='tr'>
              <input type='text' alt="6" title='Province' class='input1' name='province' value="Province">
            </div>
            <div class='tr'>
              <input type='text' alt="7" title='District'  class='input1' name='district' value="District">
            </div>
            <div class='tr'>
              <input type='text' alt="8" title='Street, Building No., Flat No., Apart No'  class='input1' name='address' value="Street, Building No., Flat No., Apart No">
            </div>
            <!-- hr -->
            <div class="row">
              <div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <hr class='hr'>
              </div>
            </div>
            <!-- end hr -->
            <div class='tr'>
              <input type='text' alt="9" title='Mobile'  class='input1' name='mobile' value="Mobile">
            </div>
            <div class='tr'>
              <input type='text' alt="10" title='Landline'  class='input1' name='landline' value="Landline">
            </div>
            <div class='tr'>
              <input type='text' alt="11" title='E-mail'  class='input1' name='e-mail' value="E-mail">
            </div>
            <div class='margin'>Other way of communication:</div>
            <div class='tr'>
              <input type='text' alt="12" title='WhatsApp, Telegram, IMO, Facebook, Twitter'  class='input1' name='other_networkings' value="WhatsApp, Telegram, IMO, Facebook, Twitter">
            </div>
          </div>
        </div>
        <!-- social icons -->
        <div class="row">
          <div class="contact-social-link text-center">
            <a href="#" data-toggle="tooltip" data-placement="top" title="First Page"><i class="fa fa-circle fa-2x social-icon" aria-hidden="true"></i></a>
            <a href="#" data-toggle="tooltip" data-placement="top" title="Second Page"><i class="fa fa-circle-thin fa-2x social-icon"></i></a>
            <a href="#" data-toggle="tooltip" data-placement="top" title="Third Page"><i class="fa fa-circle-thin fa-2x social-icon"></i></a>
            <a href="#" data-toggle="tooltip" data-placement="top" title="Forth Page"><i class="fa fa-circle-thin fa-2x social-icon"></i></a>
            <a href="#" data-toggle="tooltip" data-placement="top" title="Next" id="next2"><i class="fa fa-arrow-right fa-2x social-icon pull-right" onclick="check(1,13)" alt='13'></i></a>
          </div>
        </div>
      </div>


      <!-- 2-nd page -->
      <div id='second_page'>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-10 col-lg-10  col-xs-offset-0 col-sm-offset-0 col-md-offset-1 col-lg-offset-1  form-group wow fadeInDown" data-wow-delay="700ms" data-wow-duration="1000ms">
                <label class="sr-only" for="name">Your Name</label>
                <i class="fa fa-plus fa-2x social-icon pull-right"></i>
                <table class="table table-hover">
                    <thead>Your Wife</thead>
                    <tr>
                        <td type="button"  data-toggle="modal" data-target="#myModal_wife_husb">Name, Surname and details of the wife / husband <i class="fa fa-arrow-right pull-right"></i></td>
                    </tr>
                </table>
            </div>
        </div>
        <!-- Modal -->
        <div id="myModal_wife_husb" class="modal fade" role="dialog">
          <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Name, Surname and details of the wife / husband</h4>
              </div>
              <div class="modal-body">
                <div class='tr'>
                  <input type='text' title='Name' class='input1' name='wife_husband_name' value="Name">
                </div>
                <div class='tr'>
                  <input type='text' title='Surname' class='input1' name='wife_husband_surname' value="Surname">
                </div>
                <div class='tr'>
                  <input type='text' title='Details' class='input1' name='wife_husband_details' value="Details">
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>



        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-10 col-lg-10  col-xs-offset-0 col-sm-offset-0 col-md-offset-1 col-lg-offset-1 form-group wow fadeInDown" data-wow-delay="700ms" data-wow-duration="1000ms">
                <label class="sr-only" for="name">Your Name</label>
                <i class="fa fa-plus fa-2x social-icon pull-right"></i>
                <table class="table table-hover">
                    <thead>Your Kids</thead>
                    <tr>
                        <td type="button"  data-toggle="modal" data-target="#myModal_first_child">Name, Surname and details of the of the kid #1 <i class="fa fa-arrow-right pull-right"></i></td>
                    </tr>
                    <tr>
                        <td type="button"  data-toggle="modal" data-target="#myModal_second_child">Name, Surname and details of the of the kid #2 <i class="fa fa-arrow-right pull-right"></i></td>
                    </tr>
                </table>
            </div>
        </div>
        <!-- Modal -->
        <div id="myModal_first_child" class="modal fade" role="dialog">
          <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Name, Surname and details of the of the kid #1</h4>
              </div>
              <div class="modal-body">
                <div class='tr'>
                  <input type='text' title='Name' class='input1' name='first_child_name' value="Name">
                </div>
                <div class='tr'>
                  <input type='text' title='Surname' class='input1' name='first_child_surname' value="Surname">
                </div>
                <div class='tr'>
                  <input type='text' title='Details' class='input1' name='first_child_details' value="Details">
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>

        <!-- Modal -->
        <div id="myModal_second_child" class="modal fade" role="dialog">
          <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Name, Surname and details of the of the kid #2</h4>
              </div>
              <div class="modal-body">
                <div class='tr'>
                  <input type='text' title='Name' class='input1' name='second_child_name' value="Name">
                </div>
                <div class='tr'>
                  <input type='text' title='Surname' class='input1' name='second_child_surname' value="Surname">
                </div>
                <div class='tr'>
                  <input type='text' title='Details' class='input1' name='second_child_details' value="Details">
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>

        <!-- hr -->
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-10 col-lg-10  col-xs-offset-0 col-sm-offset-0 col-md-offset-1 col-lg-offset-1 ">
            <hr class='hr'>
          </div>
        </div>
        <!-- end hr -->
        <div class='row'>
          <div class='row col-xs-10 col-sm-10 col-md-10 col-lg-10 col-xs-offset-1 col-sm-offset-1 col-md-offset-1 col-lg-offset-1'>
            <div class='tr'>
              <input type='text' alt="13" title='Occupation' class='input1' name='occupation' value="Occupation">
            </div>
            <div class='tr'>
              <input type='text' alt="14" title='Where do you work' class='input1' name='place_of_work' value="Where do you work">
            </div>
            <!-- hr -->
            <div class="row">
              <div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <hr class='hr'>
              </div>
            </div>
            <!-- end hr -->
            <div class='tr'>
              <input type='text' alt="15" title='Date you enter to the country'  id='datepicker1' class='input1' name='date_you_enter_to_the_country' value="Date you enter to the country">
            </div>
            <div class='tr'>
              <input type='text' alt="16" title='Residence Permit No' class='input1' name='residence_permit_no' value="Residence Permit No">
            </div>
            <div class='tr flex_space_betw  flex_item_align'>
              <div class='flex_item_50 '>
                Type of Residence Permit
              </div>
              <div class='flex_item_50'>
                <select name='type_of_reside'  alt="17" class="input flex_item_100" title=''>
                  <option></option>
                  <option value="parmament">Parmament</option>
                  <option value="temporary">Temporary</option>
                </select>
              </div>
            </div>
            <div class='tr'>
              <input type='text' alt="18" title='Expire date of your residence permit'  id='datepicker2' class='input1' name='expire_date_of_your_residence_permit' value="Expire date of your residence permit">
            </div>
            <!-- hr -->
            <div class="row">
              <div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <hr class='hr'>
              </div>
            </div>
            <!-- end hr -->
            <div class='tr flex_space_betw  flex_item_align'>
              <div class='flex_item_50 '>
                Level of Education
              </div>
              <div class='flex_item_50'>
                <select name='level_of_educ' alt="19" class="input flex_item_100" title=''>
                  <option></option>
                  <option value="Uneducated">Uneducated</option>
                  <option value="diploma">Diploma</option>
                  <option value="bachelor">Bachelor</option>
                  <option value="master">Master</option>
                  <option value="ph_d">Ph. D.</option>
                </select>
              </div>
            </div>
            <div class='tr flex_space_betw  flex_item_align'>
              <div class='flex_item_50 '>
                Level of English
              </div>
              <div class='flex_item_50'>
                <select name='level_of_engl' alt="20" class="input flex_item_100" title=''>
                  <option></option>
                  <option value="beginner">Beginner</option>
                  <option value="Pre-Intermediate">Pre-Intermediate</option>
                  <option value="Intermediate">Intermediate</option>
                  <option value="Upper-Intermediate">Upper-Intermediate</option>
                  <option value="Advanced">Advanced</option>
                </select>
              </div>
            </div>
          </div>
        </div>
        <!-- social icons -->
        <div class="row">
          <div class="contact-social-link text-center">
            <a href="#" data-toggle="tooltip" data-placement="top" title="Back" id="back1"><i class="fa fa-arrow-left fa-2x social-icon pull-left"></i> </a>
            <a href="#" data-toggle="tooltip" data-placement="top" title="First Page"><i class="fa fa-circle-thin fa-2x social-icon" aria-hidden="true"></i></a>
            <a href="#" data-toggle="tooltip" data-placement="top" title="Second Page"><i class="fa fa-circle fa-2x social-icon"></i></a>
            <a href="#" data-toggle="tooltip" data-placement="top" title="Third Page"><i class="fa fa-circle-thin fa-2x social-icon"></i></a>
            <a href="#" data-toggle="tooltip" data-placement="top" title="Forth Page"><i class="fa fa-circle-thin fa-2x social-icon"></i></a>
            <a href="#" data-toggle="tooltip" data-placement="top" title="Next" id="next3"><i class="fa fa-arrow-right fa-2x social-icon pull-right" onclick='check(13,21)' alt='21'></i></a>
          </div>
        </div>
      </div>




      <!-- 3-rd page -->
      <div id='third_page'>
        <div class='row'>
          <div class='row col-xs-10 col-sm-10 col-md-10 col-lg-10 col-xs-offset-1 col-sm-offset-1 col-md-offset-1 col-lg-offset-1'>
            <div class='flex_center'>
              <div class='flex_item_50'>
                Blood Group:
                <select name='blood_group' alt="21" class='short_select' title=''>
                  <option></option>
                  <option>0</option>
                  <option>A</option>
                  <option>B</option>
                </select>
              </div>
              <div class='flex_item_50'>
                Rh:
                <select name='rh' alt="22" class='short_select' title=''>
                  <option></option>
                  <option>-</option>
                  <option>+</option>
                </select>
              </div>
            </div>
            <div class='tr margin-top_20'>
              Medical Insurance :
              <input type="radio" checked name="medical_insurance" value="yes"><span class='checkbox_text'>Yes</span>
              <input type="radio" name='medical_insurance' value="no"><span class='checkbox_text'>No</span>
            </div>
            <div class='tr'>
              <input type='text' alt="23" class="input1" name='chron_diseases' title='Chronical Diseases' value='Chronical Diseases'>
            </div>
            <div class='tr'>
              Medical Notes
            </div>
            <div class='tr'>
              <input type='text' alt="24" class="input1" name='medical_notes' title='Issues, broken bones, etc.' value='Issues, broken bones, etc.'>
            </div>
          </div>
        </div>
        <!-- social icons -->
        <div class="row">
          <div class="contact-social-link text-center">
            <a href="#" data-toggle="tooltip" data-placement="top" title="Back" id="back2"><i class="fa fa-arrow-left fa-2x social-icon pull-left"></i> </a>
            <a href="#" data-toggle="tooltip" data-placement="top" title="First Page"><i class="fa fa-circle-thin fa-2x social-icon" aria-hidden="true"></i></a>
            <a href="#" data-toggle="tooltip" data-placement="top" title="Second Page"><i class="fa fa-circle-thin fa-2x social-icon"></i></a>
            <a href="#" data-toggle="tooltip" data-placement="top" title="Third Page"><i class="fa fa-circle fa-2x social-icon"></i></a>
            <a href="#" data-toggle="tooltip" data-placement="top" title="Forth Page"><i class="fa fa-circle-thin fa-2x social-icon"></i></a>
            <a href="#" data-toggle="tooltip" data-placement="top" title="Next" id="next4"><i class="fa fa-arrow-right fa-2x social-icon pull-right" onclick="check(21,25)" alt='25'></i></a>
          </div>
        </div>

      </div>










      <!-- 4-th page -->
      <div id='fourth_page'>
        <div class='row'>
          <div class='row col-xs-10 col-sm-10 col-md-10 col-lg-10 col-xs-offset-1 col-sm-offset-1 col-md-offset-1 col-lg-offset-1'>
            <div class='tr'>
              How you can help other community members:
            </div>
            <div class='tr'>
              <input type='text' alt="25" class='input1' name='mentorship_training_educating_donation_volunteering' title='Mentorship, training, educating, donation, volunteering etc.' value='Mentorship, training, educating, donation, volunteering etc.'>
            </div>
            <div class='tr'>
              Messages for the community:
            </div>
            <div class='tr'>
              <input type='text' alt="26" class='input1' name='advices_problems' title='Advices, problems etc.' value='Advices, problems etc.'>
            </div>
          </div>
        </div>
        <!-- social icons -->
        <div class="row">
          <div class="contact-social-link text-center" style='position:relative;'>
            <a href="#" data-toggle="tooltip" data-placement="top" title="Back" id="back3"><i class="fa fa-arrow-left fa-2x social-icon pull-left"></i> </a>
            <a href="#" data-toggle="tooltip" data-placement="top" title="First Page"><i class="fa fa-circle-thin fa-2x social-icon" aria-hidden="true"></i></a>
            <a href="#" data-toggle="tooltip" data-placement="top" title="Second Page"><i class="fa fa-circle-thin fa-2x social-icon"></i></a>
            <a href="#" data-toggle="tooltip" data-placement="top" title="Third Page"><i class="fa fa-circle-thin fa-2x social-icon"></i></a>
            <a href="#" data-toggle="tooltip" data-placement="top" title="Forth Page"><i class="fa fa-circle fa-2x social-icon"></i></a>




            <input type="submit" class="btn btn-info" style='background-color:#337ab7;!important' onclick='save()' name="submit"  value="Save" alt='27'>
          </div>
        </div>
      </div>

    </form>
</div>
</body>
</html>
